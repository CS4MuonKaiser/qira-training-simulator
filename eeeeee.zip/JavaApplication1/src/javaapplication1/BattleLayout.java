/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * @author kaise
 */

public class BattleLayout extends JFrame{
    private JLabel map, enemyName, enemyHP, enemyIcon, playerName, playerHP, playerMana, playerIcon;
    private JButton attack, spells, items, stall;
    private JPanel mapPanel, enemyPanel, playerPanel, abilityPanel, enemyIPanel, playerIPanel;
    public BattleLayout(){
        super("Battle!");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(512,512);
        this.setVisible(true);
        this.setLayout(new GridLayout(2,2));
        ImageIcon img;
        map = new JLabel();
        enemyName = new JLabel("T-Rex");
        enemyHP = new JLabel("HP: 100/100");
        enemyIcon = new JLabel();
        playerName = new JLabel("You");
        playerHP = new JLabel("50/50");
        playerMana = new JLabel("100/100");
        playerIcon = new JLabel();
        attack = new JButton("Attack");
        spells = new JButton("Spells");
        items = new JButton("Items");
        stall = new JButton("stall");
        this.map.setHorizontalTextPosition(JLabel.CENTER);
        this.map.setVerticalTextPosition(JLabel.BOTTOM);
        mapPanel = new JPanel();
        mapPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        img = new ImageIcon(JavaApplication1.class.getResource("Map.jpg"));
        map.setIcon(img);
        mapPanel.add(map);
        enemyPanel = new JPanel();
        enemyPanel.setLayout(new GridLayout(1,2));
        enemyIPanel.setLayout(new BoxLayout(enemyIPanel, BoxLayout.Y_AXIS));
        enemyIPanel.add(enemyName);
        enemyIPanel.add(enemyHP);
        img = new ImageIcon(JavaApplication1.class.getResource("IlegalTRe.jpg"));
        enemyIcon.setIcon(img);
        enemyPanel.add(enemyIPanel);
        enemyPanel.add(enemyIcon);
        playerPanel = new JPanel();
        playerPanel.setLayout(new GridLayout(1,2));
        playerIPanel.setLayout(new BoxLayout(enemyIPanel, BoxLayout.Y_AXIS));
        playerIPanel.add(playerName);
        playerIPanel.add(playerHP);
        playerIPanel.add(playerMana);
        img = new ImageIcon(JavaApplication1.class.getResource("man.jpg"));
        playerIcon.setIcon(img);
        playerPanel.add(playerIcon);
        playerPanel.add(playerIPanel);
        this.add(map);
        this.add(enemyPanel);
        this.add(playerPanel);
    }
}